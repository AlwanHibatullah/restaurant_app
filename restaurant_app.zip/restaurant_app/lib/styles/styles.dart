import 'package:flutter/widgets.dart';

final Color primaryColor = Color(0xFF356859);
final Color secondaryColor = Color(0xFFFD5523);
final Color supportColor1 = Color(0xFF37966F);
final Color supportColor2 = Color(0xFFC7F0DB);
final Color supportColor3 = Color(0xFFFFFBE6);