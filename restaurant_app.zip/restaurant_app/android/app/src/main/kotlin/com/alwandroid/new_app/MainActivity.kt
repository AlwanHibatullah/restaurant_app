package com.alwandroid.new_app

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
